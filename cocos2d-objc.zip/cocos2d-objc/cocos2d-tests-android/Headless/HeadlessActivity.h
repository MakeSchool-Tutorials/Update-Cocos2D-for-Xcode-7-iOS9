//
//  HeadlessActivity.h
//  Headless
//
//  Created by Philippe Hausler on 7/8/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "CCActivity.h"

BRIDGE_CLASS("com.apportable.GLActivity")
@interface HeadlessActivity : CCActivity

@end
