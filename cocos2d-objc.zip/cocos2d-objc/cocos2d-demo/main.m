//
//  main.m
//  cocos2d-demo
//
//  Created by Lars Birkemose on 20/07/15.
//  Copyright Cocos2D 2015. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, @"AppDelegate");
        return retVal;
    }
}
