//
//  dummy.c
//  cocos2d
//
//  Created by Viktor on 1/26/15.
//
//

#include <stdio.h>


