//
//  cocos2dMacFramework.h
//  cocos2dMacFramework
//
//  Created by Viktor on 1/26/15.
//
//

#import <Cocoa/Cocoa.h>

//! Project version number for cocos2dMacFramework.
FOUNDATION_EXPORT double cocos2dMacFrameworkVersionNumber;

//! Project version string for cocos2dMacFramework.
FOUNDATION_EXPORT const unsigned char cocos2dMacFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <cocos2dMacFramework/PublicHeader.h>


