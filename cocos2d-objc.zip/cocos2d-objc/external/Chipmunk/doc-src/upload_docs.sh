rsync -r --exclude=".*" ../ slembcke.net:files.slembcke.net/chipmunk/release/Chipmunk-5.x/Chipmunk-Docs/
