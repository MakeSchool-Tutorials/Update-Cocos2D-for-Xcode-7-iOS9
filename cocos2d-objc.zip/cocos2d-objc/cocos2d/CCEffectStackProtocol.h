//
//  CCEffectStackProtocol.h
//  cocos2d-ios
//
//  Created by Thayer J Andrews on 6/19/14.
//
//

#import <Foundation/Foundation.h>


// not documented, considered a private protocol
@protocol CCEffectStackProtocol <NSObject>

- (void)passesDidChange:(id)sender;

@end
