//
//  CCPlatformTextField.m
//  cocos2d-osx
//
//  Created by Sergey Klimov on 7/1/14.
//
//

#import "CCPlatformTextField.h"

@implementation CCPlatformTextField
@synthesize delegate=_delegate;
- (void) positionInControl:(CCControl *)control padding:(CGFloat)padding {
    
}
- (void) onEnterTransitionDidFinish {
    
}
- (void) onExitTransitionDidStart {
    
}
- (void) setFontSize:(float)fontSize {
    
}


@end
