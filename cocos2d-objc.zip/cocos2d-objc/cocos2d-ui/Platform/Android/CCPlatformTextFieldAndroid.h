//
//  CCPlatformTextFieldAndroid.h
//  cocos2d-osx
//
//  Created by Sergey Klimov on 7/1/14.
//
//

#import "CCPlatformTextField.h"

@interface CCPlatformTextFieldAndroid : CCPlatformTextField

@end
